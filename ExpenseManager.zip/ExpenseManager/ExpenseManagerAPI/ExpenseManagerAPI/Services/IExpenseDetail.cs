﻿using ExpenseManagerAPI.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ExpenseManagerAPI.Services
{
    public interface IExpenseDetail
    {
        Task <IEnumerable<ExpenseDetail>> GetExpenseDetails();

        Task <ExpenseDetail> GetExpenseDetail(int Id);
        Task Add(ExpenseDetail ExpenseDetail);
        Task Update(ExpenseDetail ExpenseDetail);

        Task Remove(int Id);
    }
}
