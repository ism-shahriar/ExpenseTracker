﻿using ExpenseManagerAPI.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ExpenseManagerAPI.Services
{
    public interface IExpenseCategory
    {
        Task <IEnumerable<ExpenseCategory>> GetExpenseCategories();

        Task <ExpenseCategory> GetExpenseCategory(int Id);
        Task Add(ExpenseCategory ExpenseCategory);
        Task Update(ExpenseCategory ExpenseCategory);

        Task Remove(int Id);
    }
}
