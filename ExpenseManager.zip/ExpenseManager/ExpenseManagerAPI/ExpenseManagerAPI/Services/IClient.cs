﻿using ExpenseManagerAPI.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ExpenseManagerAPI.Services
{
    public interface IClient
    {
        Task <IEnumerable<Client>> GetClients();
        Task <Client> GetClient(int Id);
        Task Add(Client client);
        Task Update(Client client);
        Task Remove(int Id);
    }
}
