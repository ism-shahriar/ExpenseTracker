﻿using ExpenseManagerAPI.Entities;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ExpenseManagerAPI.Services
{
    public class ExpenseDetailRepository:IExpenseDetail
    {
        private ExpenseManagerDBContext db;
        public ExpenseDetailRepository(ExpenseManagerDBContext _db)
        {
            db = _db;
        }
        //Getting all the client from the Database in the following line 
        public async Task<IEnumerable<ExpenseDetail>> GetExpenseDetails()
        {
            IEnumerable<ExpenseDetail> detail = db.ExpenseDetails.AsEnumerable();

            return await Task.FromResult(detail.ToList());
        }
        public Task Add(ExpenseDetail detail)
        {
            db.ExpenseDetails.Add(detail);
            db.SaveChanges();
            return Task.CompletedTask;

        }

        public Task <ExpenseDetail> GetExpenseDetail(int Id)
        {
            ExpenseDetail dbEntity = db.ExpenseDetails.Find(Id);
            return Task.FromResult(dbEntity);
        }

        public Task Remove(int Id)
        {
            ExpenseDetail dbEntity = db.ExpenseDetails.Find(Id);
            db.ExpenseDetails.Remove(dbEntity);
            db.SaveChanges();
            return Task.CompletedTask;

        }

        public Task Update(ExpenseDetail detail)
        {
            var beforeUpdate = db.ExpenseDetails.Single(s => s.TransactionID == detail.TransactionID);
            beforeUpdate.ClientID = detail.ClientID;
            beforeUpdate.CategoryID = detail.CategoryID;
            beforeUpdate.AmountSpent = detail.AmountSpent;
            
            db.ExpenseDetails.Update(beforeUpdate);
            db.SaveChanges();
            return Task.CompletedTask;
        }
    }
}
