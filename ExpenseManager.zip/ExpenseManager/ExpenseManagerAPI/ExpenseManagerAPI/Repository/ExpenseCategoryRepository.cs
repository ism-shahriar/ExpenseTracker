﻿using ExpenseManagerAPI.Entities;
using ExpenseManagerAPI.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;


namespace ExpenseManagerAPI.Services
{
    public class ExpenseCategoryRepository : IExpenseCategory
    {
        private ExpenseManagerDBContext db;
        public ExpenseCategoryRepository(ExpenseManagerDBContext _db)
        {
            db = _db;
        }
        //Getting all the client from the Database in the following line 
        public async Task<IEnumerable<ExpenseCategory>> GetExpenseCategories()
        {
            IEnumerable<ExpenseCategory> expCat = db.ExpenseCategories.AsEnumerable();

            return await Task.FromResult(expCat.ToList());
        }
        public Task Add(ExpenseCategory expCat)
        {
            db.ExpenseCategories.Add(expCat);
            db.SaveChanges();
            return Task.CompletedTask;

        }

        public Task <ExpenseCategory> GetExpenseCategory(int Id)
        {
            ExpenseCategory dbEntity = db.ExpenseCategories.Find(Id);
            return Task.FromResult(dbEntity);
        }

        public Task Remove(int Id)
        {
            ExpenseCategory dbEntity = db.ExpenseCategories.Find(Id);
            db.ExpenseCategories.Remove(dbEntity);
            db.SaveChanges();
            return Task.CompletedTask;
        }

        public Task Update(ExpenseCategory category)
        {
            var beforeUpdate = db.ExpenseCategories.Single(s => s.CategoryID == category.CategoryID);
            beforeUpdate.CategoryType = category.CategoryType;
            beforeUpdate.CategoryDetails = category.CategoryDetails;

            db.ExpenseCategories.Update(beforeUpdate);
            db.SaveChanges();
            return Task.CompletedTask;
        }
    }
}
