﻿using ExpenseManagerAPI.Entities;
using ExpenseManagerAPI.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ExpenseManagerAPI.Services
{
    public class ClientRepository:IClient
    {
        private ExpenseManagerDBContext db;
        public ClientRepository(ExpenseManagerDBContext _db)
        {
            db = _db;
        }
        //Getting all the client from the Database in the following line 
        public async Task<IEnumerable<Client>> GetClients()
        {
            IEnumerable<Client> client = db.Clients.AsEnumerable();

            return await Task.FromResult(client.ToList());
        }
        
        public Task Add(Client client)
        {
            db.Clients.Add(client);
            db.SaveChanges();
            return Task.CompletedTask;

        }

        public Task <Client> GetClient(int Id)
        {
            Client dbEntity = db.Clients.Find(Id);
            return Task.FromResult(dbEntity);

        }

        public Task Remove(int Id)
        {
            Client dbEntity = db.Clients.Find(Id);
            db.Clients.Remove(dbEntity);
            db.SaveChanges();
            return Task.CompletedTask;

        }

        public Task Update(Client client)
        {
            var beforeUpdate = db.Clients.Single(s => s.ClientId == client.ClientId);
            beforeUpdate.FirstName = client.FirstName;
            beforeUpdate.LastName = client.LastName;
            beforeUpdate.DOB = client.DOB;
            beforeUpdate.Address = client.Address;
            beforeUpdate.Email = client.Email;
            beforeUpdate.Phone = client.Phone;

            db.Clients.Update(beforeUpdate);
            db.SaveChanges();
            return Task.CompletedTask;
        }
    }
}
